// const fakeNews = ['A cat scored a goal at the World Cup.','Hurricane Harvey hit Texas in August, evacuating thousands. A Canadian imam has been accused of denying Christian victims refuge in a mosque.','The U.S. found that each mask contained an antenna that China used to steal the privacy of the American people.','There is news that the millimeter-wave spectrum used by 5G technology may spread the new coronavirus.','Alien invasion of Earth','A softball pitcher named Sid Finch, who can throw a ball at 150 miles an hour','Six-year-old boy mistakenly carried 2,000 meters in a helium balloon','Bananas and rock sugar can cure a cough','Gargling warm water with salt or vinegar can cure Covid-19','Everyone can get rich through the Internet','Musk has successfully landed on Mars!','Lebron James won the playoffs this year']
// const realNews = ['13-year-old boy made $300 by reselling sneakers.','The 105-year-old posted a selfie on social media.','Barcelona 1-1 draw with Real Madrid.','Due to the impact of the epidemic, many countries have blocked coastal ports and borders.','The U.S. found that each mask contained an antenna that China used to steal the privacy of the American people.','Roger Federer is the tennis world champion!','The Covid-19 may cause irreversible damage to human physiological functions','The Australian border reopened this year']

function Game() {
    this.row = 25;  // 行数
    this.col = 25;  // 列数
    this.score = 0;   //分数
    this.fakeScore = 0
    this.fakeNews = ['Artist sells invisible sculpture for more than £12,000','Police Appeal for Information About Chicken Crossing Road','Japanese fans say Godzilla is too fat','Sea monster washes ashore in NZ','Trump campaign offered actors $50 to cheer for presidential announcement','Eight-year-old girl pulls medieval sword from lake','Nasa is installing internet on the moon','Photo from tornado-damaged home lands almost 210km away','Mosquito explosion coming as La Niña brings soaking rains','Tens of thousands new COVID-19 cases across Australia','NSW and Victoria record more than 19,000 COVID-19 cases in 24 hours','New Omicron sub-variants detected in two Australian states','Over 38,600 new cases of COVID-19 in Australia as flu season approaches','More than 3000 Victorians have now died from COVID-19','A cat scored a goal at the World Cup.','Hurricane Harvey hit Texas in August, evacuating thousands. A Canadian imam has been accused of denying Christian victims refuge in a mosque.','The U.S. found that each mask contained an antenna that China used to steal the privacy of the American people.','There is news that the millimeter-wave spectrum used by 5G technology may spread the new coronavirus.','Alien invasion of Earth','A softball pitcher named Sid Finch, who can throw a ball at 150 miles an hour','Six-year-old boy mistakenly carried 2,000 meters in a helium balloon','Bananas and rock sugar can cure a cough','Gargling warm water with salt or vinegar can cure Covid-19','Everyone can get rich through the Internet','Musk has successfully landed on Mars!','Lebron James won the playoffs this year']
    this.realNews = ['California theme park bans screaming because of Covid-19','Climate activist Greta Thunberg told people in China to stop using chopsticks to save trees','Man Eats Girlfriends Booty for the first time dies from E.Coli','Two alter boys were arrested for putting weed in the censer-burner','Former first lady Barbara Bush dies at 92','Lottery winner arrested for dumping $200,000 of manure on ex-boss lawn','Milwaukee County Sheriff David A. Clarke is a KKK member',' Elizabeth Warren endorsed Bernie Sanders','The NBA cancels 2017 All-Star Game in North Carolina','A university banned the use of capital letters to avoid scaring students','Couple in California name baby with emoji','World’s first hotdog ATM opens in Malaysia','Scientists create a plant that cannot die','Polar bears scream when they poo','13-year-old boy made $300 by reselling sneakers.','The 105-year-old posted a selfie on social media.','Barcelona 1-1 draw with Real Madrid.','Due to the impact of the epidemic, many countries have blocked coastal ports and borders.','The U.S. found that each mask contained an antenna that China used to steal the privacy of the American people.','Roger Federer is the tennis world champion!','The Covid-19 may cause irreversible damage to human physiological functions','The Australian border reopened this year']
    this.fakeNewsArrayIndexs = Array.from(Array(this.fakeNews.length), (v,k) =>k);
    this.fakeNewsIndex = 0
    this.realNewsArrayIndexs = Array.from(Array(this.realNews.length), (v,k) =>k);
    this.realNewsIndex = 0
    this.init();    //初始化节点
    this.snake = new Snake();  //实例化蛇类
    this.food = new Food(this);   //初始化食物
    // this.last = new Last();
    this.start();   //执行定时器任务
    this.bindEvent();   //键盘的事件监听
    this.d = 'R';
    
}


Game.prototype.init = function () {
    this.dom = document.createElement('table'); // 创建表格
    var tr, td;
    // 遍历行和列
    for (var i = 0; i < this.row; i++) {
        tr = document.createElement('tr');  // 创建行
        for (var j = 0; j < this.col; j++) {
            td = document.createElement('td');  // 创建列
            tr.appendChild(td);     // 把列追加到行
        }
        this.dom.appendChild(tr);   // 把行追加到表格
    }
    document.querySelector('#app').appendChild(this.dom);   //把表格追加到div里
    this.fakeNewsArrayIndexs.sort(()=> 0.5 - Math.random());
    this.realNewsArrayIndexs.sort(()=> 0.5 - Math.random());
}

Game.prototype.getFakeNews = function(){
    const index = this.fakeNewsArrayIndexs[this.fakeNewsIndex]
    // console.log('fake index ',this.fakeNewsIndex)
    const news = this.fakeNews[index]
    if (this.fakeNewsIndex+1>=this.fakeNewsArrayIndexs.length){
        this.fakeNewsIndex = 0
    }else{
        this.fakeNewsIndex = this.fakeNewsIndex + 1
    }
    
    return news
}

Game.prototype.getRealNews = function(){
    const index = this.realNewsArrayIndexs[this.realNewsIndex]
    // console.log('reak index ',this.realNewsIndex)
    const news = this.realNews[index]
    if (this.realNewsIndex+1>=this.realNewsArrayIndexs.length){
        this.realNewsIndex = 0
    }else{
        this.realNewsIndex = this.realNewsIndex + 1
    }
    return news
}


// 遍历表格，清除表格上的颜色
Game.prototype.clear = function () {
    for (var i = 0; i < this.row; i++) {
        for (var j = 0; j < this.col; j++) {
            this.dom.getElementsByTagName('tr')[i].getElementsByTagName('td')[j].style.background = '';
            this.dom.getElementsByTagName('tr')[i].getElementsByTagName('td')[j].innerHTML = '';
        }
    }
}
// 设置颜色的方法 让表格的第几行，第几列设置什么颜色
Game.prototype.setColor = function (row, col, color) {
    this.dom.getElementsByTagName('tr')[row].getElementsByTagName('td')[col].style.background = color;
}
// 设置蛇头
Game.prototype.setColorHead = function (row, col) {
    var img = document.createElement('img');
    img.src = 'images/snake.png';
    img.className = 'snake';
    this.dom.getElementsByTagName('tr')[row].getElementsByTagName('td')[col].appendChild(img);
    // this.dom.getElementsByTagName('tr')[row].getElementsByTagName('td')[col].style.backgroundColor='transparent'
    switch (this.d) {
        case 'R':   //右
                break;
        case 'D':   //下
                img.style.transform = 'rotate(90deg)';
                break;
        case 'L':   //左
                img.style.transform = 'rotate(180deg)';
                break;
        case 'U':   //上
                img.style.transform = 'rotate(-90deg)';
                break;
    }
}
// 渲染食物
Game.prototype.setHTML = function (row, col) {
    this.dom.getElementsByTagName('tr')[row].getElementsByTagName('td')[col].style.backgroundImage = 'url(./images/food.png)';
    // if (this.food.isfake){
    //     this.dom.getElementsByTagName('tr')[row].getElementsByTagName('td')[col].style.backgroundImage = 'url(./images/food2.png)';
    // }else{
    //     this.dom.getElementsByTagName('tr')[row].getElementsByTagName('td')[col].style.backgroundImage = 'url(./images/food.png)';
    // }
    
}
// 设置键盘的事件监听
Game.prototype.bindEvent = function () {
    var self = this;
    document.addEventListener('keydown', function (e) {
        // 用ASCII码值判断键盘方向
        switch (e.keyCode) {
            case 37:    //左
                if (self.snake.direction == 'R') return;    // 先进行判断，如果当前的方向是向右移动，此时我们不能按左键
                self.snake.changeDirection('L');
                self.d = 'L';
                break;
            case 38:    //上
                if (self.snake.direction == 'D') return;    // 先进行判断，如果当前的方向是向下移动，此时我们不能按上键
                self.snake.changeDirection('U');
                self.d = 'U';
                break;
            case 39:    //右
                if (self.snake.direction == 'L') return;    // 先进行判断，如果当前的方向是向左移动，此时我们不能按右键
                self.snake.changeDirection('R');
                self.d = 'R';
                break;
            case 40:    //下
                if (self.snake.direction == 'U') return;    // 先进行判断，如果当前的方向是向上移动，此时我们不能按下键
                self.snake.changeDirection('D');
                self.d = 'D';
                break;
            case 32:
                game.food = new Food(game);
                break;
        }
    })
}
Game.prototype.start = function () {
    // 帧编号
    this.f = 0;
    // 定时器里面的核心就是游戏的渲染本质：清屏-更新-渲染
    this.timer = setInterval(function () {
        game.f++;
        document.getElementById('score').innerHTML = 'real fruits eaten:' + game.score +'<br/>' + 'fake fruits eaten:'+game.fakeScore;
        // document.getElementById('f').innerHTML = '帧编号：' + game.f;
        // 清屏
        game.clear();
        // 蛇的运动（更新）
        // 蛇的更新速度，当蛇变长的时候，速度要加快
        var during = game.snake.body.length < 30 ? 30 - game.snake.body.length : 1;
        game.f % during == 0 && game.snake.update();
        // game.snake.update();
        // 渲染蛇
        game.snake.render();
        // 渲染食物
        game.food.render();
    }, 10)
}